const express = require('express');
const socketio = require('socket.io');
const http = require('http');
const { v4: uuidv4 } = require('uuid');
const bodyParser = require('body-parser');
const cors = require('cors');
const { PythonShell } = require('python-shell');
const fs = require('fs');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = socketio(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

// Enable CORS and body parsing
app.use(cors());
app.use(bodyParser.json());

// Store documents in memory (for production, use a database)
const documents = {};

// Serve static files from public directory
app.use(express.static('public'));

// Create temp directory if it doesn't exist
const tempDir = path.join(__dirname, 'temp');
if (!fs.existsSync(tempDir)) {
  fs.mkdirSync(tempDir);
}

// Enhanced Python execution with better error handling
async function executePython(code) {
  return new Promise((resolve, reject) => {
    const filename = `python_${uuidv4()}.py`;
    const filepath = path.join(tempDir, filename);

    // Write code to temporary file
    fs.writeFileSync(filepath, code);

    const options = {
      mode: 'text',
      pythonOptions: ['-u'], // unbuffered stdout
      scriptPath: tempDir,
      args: []
    };

    const pyshell = new PythonShell(filename, options);
    
    let output = '';
    let errorOutput = '';
    let timeout = setTimeout(() => {
      pyshell.childProcess.kill();
      reject(new Error('Execution timed out (5 seconds)'));
    }, 5000);

    pyshell.on('message', (message) => {
      output += message + '\n';
    });

    pyshell.on('stderr', (stderr) => {
      errorOutput += stderr + '\n';
    });

    pyshell.end((err) => {
      clearTimeout(timeout);
      
      // Clean up temp file
      try {
        fs.unlinkSync(filepath);
      } catch (e) {
        console.error('Error cleaning up temp file:', e);
      }

      if (err) {
        reject(new Error(errorOutput || err.message || 'Python execution failed'));
      } else if (errorOutput) {
        reject(new Error(errorOutput));
      } else {
        resolve(output.trim() || 'Code executed (no output)');
      }
    });
  });
}

// API endpoint to execute code
app.post('/execute', async (req, res) => {
  const { code, language } = req.body;
  console.log(`Executing ${language} code (${code.length} chars)`);
  
  try {
    // Basic code validation
    if (!code || typeof code !== 'string' || code.length > 10000) {
      throw new Error('Invalid code');
    }

    let result;
    if (language === 'javascript') {
      // JavaScript execution with safer approach
      const fn = new Function(`
        try {
          const __result = (function() { 
            ${code}
          })();
          return typeof __result === 'undefined' ? 'undefined' : JSON.stringify(__result);
        } catch (e) {
          return 'Error: ' + e.message;
        }
      `);
      const rawResult = fn();
      result = rawResult === 'undefined' ? 'undefined' : JSON.parse(rawResult);
    } else if (language === 'python') {
      // Python execution
      result = await executePython(code);
    } else {
      result = `Execution for ${language} not implemented yet`;
    }
    
    console.log('Execution successful');
    res.json({ success: true, result: String(result) });
  } catch (error) {
    console.error('Execution error:', error.message);
    res.json({ 
      success: false, 
      error: error.message || 'Unknown execution error' 
    });
  }
});

// Socket.io connection handling
io.on('connection', (socket) => {
  console.log('New client connected:', socket.id);
  
  socket.on('join', (documentId) => {
    if (!documents[documentId]) {
      documents[documentId] = { 
        content: '', 
        language: 'javascript',
        users: [] 
      };
    }
    
    socket.join(documentId);
    socket.emit('load', { 
      content: documents[documentId].content,
      language: documents[documentId].language
    });
    
    const userId = uuidv4();
    documents[documentId].users.push(userId);
    socket.userId = userId;
    socket.documentId = documentId;
    
    socket.to(documentId).emit('user-connected', userId);
  });
  
  socket.on('text-change', (delta) => {
    const documentId = socket.documentId;
    if (documents[documentId]) {
      documents[documentId].content = delta;
      socket.to(documentId).emit('text-change', delta);
    }
  });
  
  socket.on('language-change', (language) => {
    const documentId = socket.documentId;
    if (documents[documentId]) {
      documents[documentId].language = language;
      socket.to(documentId).emit('language-change', language);
    }
  });
  
  socket.on('cursor-change', (range) => {
    const documentId = socket.documentId;
    socket.to(documentId).emit('cursor-change', {
      userId: socket.userId,
      range
    });
  });
  
  socket.on('disconnect', () => {
    const documentId = socket.documentId;
    if (documentId && documents[documentId]) {
      documents[documentId].users = documents[documentId].users.filter(
        id => id !== socket.userId
      );
      socket.to(documentId).emit('user-disconnected', socket.userId);
    }
    console.log('Client disconnected:', socket.id);
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Server error:', err);
  res.status(500).json({ error: 'Internal server error' });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`Python execution available: ${PythonShell.defaultOptions.pythonPath || 'python'}`);
});

// Clean up temp files on exit
process.on('SIGINT', () => {
  console.log('Cleaning up temp files...');
  if (fs.existsSync(tempDir)) {
    fs.readdirSync(tempDir).forEach(file => {
      fs.unlinkSync(path.join(tempDir, file));
    });
    fs.rmdirSync(tempDir);
  }
  process.exit();
});