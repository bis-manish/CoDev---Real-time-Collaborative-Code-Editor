const { PythonShell } = require('python-shell');

async function executePython(code) {
    return new Promise((resolve, reject) => {
        const options = {
            mode: 'text',
            pythonOptions: ['-u'], // unbuffered stdout
            scriptPath: '',
            args: []
        };
        
        const pyshell = new PythonShell('dummy.py', options);
        
        // Send the code to the Python process
        pyshell.send(code);
        
        let output = '';
        
        pyshell.on('message', (message) => {
            output += message + '\n';
        });
        
        pyshell.on('stderr', (stderr) => {
            output += stderr + '\n';
        });
        
        pyshell.end((err) => {
            if (err) {
                reject(err);
            } else {
                resolve(output.trim() || 'Code executed (no output)');
            }
        });
    });
}

module.exports = { executePython };