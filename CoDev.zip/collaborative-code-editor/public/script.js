document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const editorTextarea = document.getElementById('editor');
    const documentIdInput = document.getElementById('documentId');
    const joinBtn = document.getElementById('joinBtn');
    const createBtn = document.getElementById('createBtn');
    const languageSelect = document.getElementById('languageSelect');
    const runBtn = document.getElementById('runBtn');
    const userCountElement = document.getElementById('userCount');
    const outputElement = document.getElementById('output');
    const statusElement = document.getElementById('outputStatus');
    const shareBtn = document.querySelector('.btn-outline');
    
    // Connect to socket.io
    const socket = io();
    
    // Initialize CodeMirror
    const editor = CodeMirror.fromTextArea(editorTextarea, {
        lineNumbers: true,
        mode: 'javascript',
        theme: 'dracula',
        autoCloseTags: true,
        autoCloseBrackets: true,
        indentUnit: 4,
        tabSize: 4,
        lineWrapping: true,
        extraKeys: {
            'Ctrl-Enter': runCode,
            'Cmd-Enter': runCode,
            'Ctrl-S': saveDocument,
            'Cmd-S': saveDocument
        },
        gutters: ["CodeMirror-linenumbers", "CodeMirror-foldgutter"],
        foldGutter: true,
        matchBrackets: true,
        autoFocus: true
    });
    
    // State variables
    let currentDocumentId = null;
    let connectedUsers = 0;
    let cursors = {};
    const colors = ['#4361ee', '#3f37c9', '#4cc9f0', '#4895ef', '#7209b7', '#f72585'];
    const userColor = colors[Math.floor(Math.random() * colors.length)];
    
    // Language configuration
    const languageModes = {
        javascript: 'javascript',
        python: 'python',
        java: 'text/x-java',
        c: 'text/x-csrc',
        cpp: 'text/x-c++src',
        htmlmixed: 'htmlmixed',
        css: 'css'
    };
    
    // Code templates for each language
    const codeTemplates = {
        javascript: `// JavaScript Example
function greet(name) {
    return \`Hello, \${name}!\`;
}

console.log(greet('World'));

// Collaborative coding in real-time!
// Try opening this in another browser tab.`,
        python: `# Python Example
def factorial(n):
    if n == 0:
        return 1
    else:
        return n * factorial(n-1)

print("5! =", factorial(5))

# Collaborative coding in real-time!
# Try opening this in another browser tab.`,
        java: `// Java Example
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
        System.out.println("5! = " + factorial(5));
    }
    
    public static int factorial(int n) {
        if (n == 0) return 1;
        return n * factorial(n-1);
    }
}

// Collaborative coding in real-time!
// Try opening this in another browser tab.`,
        c: `// C Example
#include <stdio.h>

int factorial(int n) {
    if (n == 0) return 1;
    return n * factorial(n-1);
}

int main() {
    printf("Hello, World!\\n");
    printf("5! = %d\\n", factorial(5));
    return 0;
}

// Collaborative coding in real-time!
// Try opening this in another browser tab.`,
        cpp: `// C++ Example
#include <iostream>
using namespace std;

int factorial(int n) {
    if (n == 0) return 1;
    return n * factorial(n-1);
}

int main() {
    cout << "Hello, World!" << endl;
    cout << "5! = " << factorial(5) << endl;
    return 0;
}

// Collaborative coding in real-time!
// Try opening this in another browser tab.`,
        htmlmixed: `<!DOCTYPE html>
<html>
<head>
    <title>Collaborative Editor</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            padding: 50px;
        }
        h1 {
            color: #4361ee;
        }
    </style>
</head>
<body>
    <h1>Welcome to Collaborative Coding!</h1>
    <p>Try opening this in another browser tab.</p>
    
    <script>
        // Your JavaScript code here
        console.log("Hello from HTML!");
    </script>
</body>
</html>`,
        css: `/* CSS Example */
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f5f7fa;
    color: #333;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}

.header {
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

/* Collaborative coding in real-time!
   Try opening this in another browser tab. */`
    };

    // Event Listeners
    joinBtn.addEventListener('click', joinDocumentHandler);
    createBtn.addEventListener('click', createDocumentHandler);
    languageSelect.addEventListener('change', languageChangeHandler);
    runBtn.addEventListener('click', runCode);
    shareBtn.addEventListener('click', shareDocument);
    window.addEventListener('beforeunload', handleBeforeUnload);

    // Initialize
    checkUrlForDocumentId();
    setupSocketListeners();
    setupEditorListeners();

    // Functions
    function joinDocumentHandler() {
        const docId = documentIdInput.value.trim();
        if (docId) {
            joinDocument(docId);
        } else {
            showToast('Please enter a document ID');
        }
    }

    function createDocumentHandler() {
        const newDocId = generateDocumentId();
        documentIdInput.value = newDocId;
        joinDocument(newDocId);
        showToast('New document created');
    }

    function languageChangeHandler() {
        const language = languageSelect.value;
        if (currentDocumentId) {
            socket.emit('language-change', language);
            editor.setOption('mode', languageModes[language]);
            
            // Insert template if editor is empty
            if (editor.getValue().trim() === '') {
                editor.setValue(codeTemplates[language] || '');
            }
        }
    }

    async function runCode() {
        const code = editor.getValue();
        const language = languageSelect.value;
        
        if (!code.trim()) {
            showToast('Please enter some code to execute');
            return;
        }
        
        outputElement.textContent = 'Running...';
        statusElement.textContent = 'Executing';
        statusElement.className = 'status status-success';
        outputElement.style.color = '#d4d4d4';
        
        try {
            const response = await fetch('/execute', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ code, language })
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            
            if (data.success) {
                outputElement.textContent = data.result;
                statusElement.textContent = 'Success';
                statusElement.className = 'status status-success';
                showToast('Code executed successfully');
            } else {
                outputElement.textContent = data.error;
                statusElement.textContent = 'Error';
                statusElement.className = 'status status-error';
                showToast('Execution error: ' + data.error);
            }
        } catch (error) {
            console.error('Execution error:', error);
            outputElement.textContent = `Error: ${error.message}`;
            statusElement.textContent = 'Failed';
            statusElement.className = 'status status-error';
            showToast('Execution failed: ' + error.message);
        }
    }

    function shareDocument() {
        if (currentDocumentId) {
            const url = `${window.location.origin}${window.location.pathname}?doc=${currentDocumentId}`;
            navigator.clipboard.writeText(url).then(() => {
                showToast('Shareable link copied to clipboard!');
            }).catch(err => {
                console.error('Failed to copy URL: ', err);
                showToast('Failed to copy URL. Please try again.');
            });
        } else {
            showToast('Please join or create a document first');
        }
    }

    function saveDocument() {
        if (currentDocumentId) {
            const code = editor.getValue();
            const language = languageSelect.value;
            // In a real app, you would save to a database here
            showToast('Document state saved locally');
            return false; // Prevent default save behavior
        }
        return false;
    }

    function joinDocument(docId) {
        if (currentDocumentId) {
            socket.emit('leave', currentDocumentId);
        }
        
        currentDocumentId = docId;
        socket.emit('join', docId);
        window.history.pushState({}, '', `?doc=${docId}`);
        
        // Update UI
        document.querySelector('.tab').textContent = `${docId}.${languageSelect.value}`;
        showToast(`Joined document: ${docId}`);
    }

    function generateDocumentId() {
        return Math.random().toString(36).substring(2, 10);
    }

    function checkUrlForDocumentId() {
        const params = new URLSearchParams(window.location.search);
        const docId = params.get('doc');
        if (docId) {
            documentIdInput.value = docId;
            joinDocument(docId);
        }
    }

    function setupSocketListeners() {
        socket.on('connect', () => {
            console.log('Connected to server');
            statusElement.textContent = 'Connected';
            statusElement.className = 'status status-success';
        });

        socket.on('disconnect', () => {
            console.log('Disconnected from server');
            statusElement.textContent = 'Disconnected';
            statusElement.className = 'status status-error';
        });

        socket.on('load', ({ content, language }) => {
            editor.setValue(content);
            languageSelect.value = language;
            editor.setOption('mode', languageModes[language]);
        });

        socket.on('text-change', (content) => {
            if (content !== editor.getValue()) {
                editor.setValue(content);
            }
        });

        socket.on('language-change', (language) => {
            languageSelect.value = language;
            editor.setOption('mode', languageModes[language]);
            document.querySelector('.tab').textContent = `${currentDocumentId}.${language}`;
        });

        socket.on('user-connected', (userId) => {
            connectedUsers++;
            updateUserCount();
            createCursorElement(userId);
            showToast('New user connected');
        });

        socket.on('user-disconnected', (userId) => {
            connectedUsers--;
            updateUserCount();
            if (cursors[userId]) {
                cursors[userId].cursor.remove();
                cursors[userId].label.remove();
                delete cursors[userId];
            }
            showToast('User disconnected');
        });

        socket.on('cursor-change', ({ userId, range }) => {
            if (userId !== socket.id) {
                updateCursorPosition(userId, range.from);
            }
        });
    }

    function setupEditorListeners() {
        editor.on('change', (cm, change) => {
            if (change.origin !== 'setValue' && currentDocumentId) {
                const content = cm.getValue();
                socket.emit('text-change', content);
            }
        });

        editor.on('cursorActivity', () => {
            if (currentDocumentId) {
                const cursor = editor.getCursor();
                const range = {
                    from: cursor,
                    to: cursor
                };
                socket.emit('cursor-change', range);
            }
        });
    }

    function createCursorElement(userId) {
        if (cursors[userId]) return;

        const cursor = document.createElement('div');
        cursor.className = 'user-cursor';
        cursor.style.borderLeftColor = getColorForUserId(userId);
        
        const label = document.createElement('div');
        label.className = 'user-cursor-label';
        label.textContent = `User ${userId.substring(0, 4)}`;
        label.style.backgroundColor = getColorForUserId(userId);
        
        document.querySelector('.CodeMirror').appendChild(cursor);
        document.querySelector('.CodeMirror').appendChild(label);
        
        cursors[userId] = { cursor, label };
    }

    function updateCursorPosition(userId, pos) {
        if (!cursors[userId]) {
            createCursorElement(userId);
        }
        
        const coords = editor.cursorCoords(pos);
        const cursor = cursors[userId].cursor;
        const label = cursors[userId].label;
        
        cursor.style.left = `${coords.left}px`;
        cursor.style.top = `${coords.top}px`;
        
        label.style.left = `${coords.left}px`;
        label.style.top = `${coords.top}px`;
    }

    function getColorForUserId(userId) {
        let hash = 0;
        for (let i = 0; i < userId.length; i++) {
            hash = userId.charCodeAt(i) + ((hash << 5) - hash);
        }
        return colors[Math.abs(hash) % colors.length];
    }

    function updateUserCount() {
        userCountElement.textContent = `${connectedUsers} user${connectedUsers !== 1 ? 's' : ''} connected`;
    }

    function handleBeforeUnload(e) {
        if (currentDocumentId) {
            socket.emit('leave', currentDocumentId);
        }
    }

    function showToast(message, duration = 3000) {
        const toast = document.createElement('div');
        toast.className = 'toast-notification';
        toast.textContent = message;
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.classList.add('fade-out');
            setTimeout(() => toast.remove(), 300);
        }, duration);
    }

    // Add toast styles dynamically
    const toastStyles = document.createElement('style');
    toastStyles.textContent = `
        .toast-notification {
            position: fixed;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            background-color: #333;
            color: white;
            padding: 12px 24px;
            border-radius: 4px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 1000;
            animation: slideIn 0.3s ease-out;
        }
        
        .toast-notification.fade-out {
            animation: fadeOut 0.3s ease-in;
            opacity: 0;
        }
        
        @keyframes slideIn {
            from { bottom: -50px; opacity: 0; }
            to { bottom: 20px; opacity: 1; }
        }
        
        @keyframes fadeOut {
            from { opacity: 1; }
            to { opacity: 0; }
        }
    `;
    document.head.appendChild(toastStyles);
});